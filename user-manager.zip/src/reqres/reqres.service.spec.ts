import { Test, TestingModule } from '@nestjs/testing';
import { ReqresService } from './reqres.service';
import { HttpService } from '@nestjs/axios';

describe('ReqresService', () => {
  let service: ReqresService;

  beforeEach(async () => {
  });
  it("",()=>{
    expect(true).toBe(true);
  })
});
