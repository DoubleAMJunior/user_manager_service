import { Test, TestingModule } from '@nestjs/testing';
import { RabbitMockEventService } from './rabbit-mock-event.service';
import { ClientProxy } from '@nestjs/microservices';

describe('RabbitMockEventService', () => {
  let service: RabbitMockEventService;

  beforeEach(async () => {
  });
  it("",()=>{
    expect(true).toBe(true);
  })
});
