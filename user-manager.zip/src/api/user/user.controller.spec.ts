import { Test, TestingModule } from '@nestjs/testing';
import { UserController } from './user.controller';

describe('UserController', () => {
  let controller: UserController;

  beforeEach(async () => {
  });
  it("",()=>{
    expect(true).toBe(true);  
  })
});
